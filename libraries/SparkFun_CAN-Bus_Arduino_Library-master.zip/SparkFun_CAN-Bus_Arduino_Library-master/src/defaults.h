/*
//UNO SETUP
#ifndef	DEFAULTS_H
#define	DEFAULTS_H

#define	P_MOSI	B,3 
#define	P_MISO	B,4 
#define	P_SCK	B,5 


#define	MCP2515_CS			B,2 
#define	MCP2515_INT			D,2 
#define LED2_HIGH			B,0 
#define LED2_LOW			B,0

#endif	// DEFAULTS_H

*/
//MEGA SETUP
#ifndef	DEFAULTS_H
#define	DEFAULTS_H
//NOTE: This is Defined for the Arduino MEGA 2560. The notation x,y corresponds to the MCU pin name on the Atmel MCU Pin Name
#define	P_MOSI	B,2 //Pin 51 on the Breakout
#define	P_MISO	B,3 //Pin 50 on the Breakout
#define	P_SCK	B,1 //Pin 52 on the Breakout


#define	MCP2515_CS			B,0 //Pin 53 on the Breakout - A jumper must be used to make the connection from Pin 10 of the shield to pin 53 of the Arduino Mega
#define	MCP2515_INT			E,4 //Pin 2 on the Breakout
#define LED2_HIGH			H,5 
#define LED2_LOW			H,5

#endif	// DEFAULTS_H
